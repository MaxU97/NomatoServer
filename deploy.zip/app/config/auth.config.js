module.exports = {
  secret: "nomato-secret-key",
  secret_key: "nomato-secret-keynomato-secret-keynomato-secret-key",
  iv: "21ff96eac5cec2aa1e4f93e7a5795d7b",
};
