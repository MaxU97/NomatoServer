const authJwt = require("./authJwt.js");
const verifySignUp = require("./verifySignup.js");
module.exports = {
  authJwt,
  verifySignUp,
};
