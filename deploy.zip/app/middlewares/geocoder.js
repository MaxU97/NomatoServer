const apiKey = "AIzaSyAdvbvYMPWmQDYjHjprN9jtNKnr3WLOiFY";
const axios = require("axios");
exports.getNaturalAddress = (lat, lng) => {
  return "town";
};
