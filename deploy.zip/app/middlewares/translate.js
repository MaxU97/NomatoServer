const axios = require("axios");

exports.checkLanguages = (descEN, descLV, descRU) => {
  let EN, LV, RU;
  let en, lv, ru;
  if (descEN.length == 0) {
    en = true;
  } else {
    EN = descEN;
    en = false;
  }

  if (descRU.length == 0) {
    ru = true;
  } else {
    LV = descLV;
    ru = false;
  }

  if (descLV.length == 0) {
    lv = true;
  } else {
    RU = descRU;
    lv = false;
  }

  if (en) {
    EN = !lv ? translate(descRU, "en", "ru") : translate(descLV, "en", "lv");
  }
  if (ru) {
    RU = !en ? translate(descEN, "ru", "en") : translate(descLV, "ru", "lv");
  }
  if (lv) {
    LV = !en ? translate(descEN, "lv", "en") : translate(descRU, "lv", "ru");
  }

  return [EN, RU, LV];
};

const translate = async (text, to, from) => {
  const encodedParams = new URLSearchParams();
  encodedParams.append("text", text);
  encodedParams.append("to", to);
  encodedParams.append("from", from);

  const options = {
    method: "POST",
    url: "https://microsoft-translator-text.p.rapidapi.com/translate",
    params: {
      "to[0]": "<REQUIRED>",
      "api-version": "3.0",
      from: from,
      profanityAction: "NoAction",
      textType: "plain",
    },
    headers: {
      "content-type": "application/json",
      "X-RapidAPI-Key": process.env.RAPID_API_KEY,
      "X-RapidAPI-Host": "microsoft-translator-text.p.rapidapi.com",
    },
    data: `[{"Text":${text}}]`,
  };

  return axios.request(options);
};
